#!/usr/bin/env python
# encoding: utf-8

"""
@version: 1.0
@license: Apache Licence
@contact: yli@posbao.net
@site: http://www.piowind.com/
@software: PyCharm
@file: xici_ip.py
@time: 2017/3/20 16:25
"""


def func():
    pass


class Main():
    def __init__(self):
        pass


if __name__ == '__main__':
    pass